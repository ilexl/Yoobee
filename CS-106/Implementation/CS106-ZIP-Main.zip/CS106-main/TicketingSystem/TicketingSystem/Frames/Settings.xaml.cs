﻿using System.Windows.Controls;

namespace TicketingSystem.Frames
{
    /// <summary>
    /// Interaction logic for Settings.xaml
    /// </summary>
    public partial class Settings : Page
    {

        /// <summary>
        /// constructor for settings page
        /// </summary>
        public Settings()
        {
            InitializeComponent();
        }
    }
}
